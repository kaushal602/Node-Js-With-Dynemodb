//App.js >> routeCountry >> CountryController >> function
var express = require('express');
const router = express.Router();
global.__root = __dirname + '/';

//router.post()
var AuthController = require(__root + 'api/auth/AuthController');
router.use('/api/auth', AuthController);

var CreateUserTableController = require(__root + 'controller/user/CreateUserTableController');
router.get('/api', CreateUserTableController);

var CategoryController = require(__root + 'controller/master/CategoryController');
router.use('/api/category', CategoryController);

var SubCategoryController = require(__root + 'controller/master/SubCategoryController');
router.use('/api/subcategory', SubCategoryController);

var CountryController = require(__root + 'controller/master/CountryController');
router.use('/api/country', CountryController);

module.exports = router;