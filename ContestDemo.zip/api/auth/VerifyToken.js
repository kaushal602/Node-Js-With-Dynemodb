var jwt = require('jsonwebtoken'); // used to create, sign, and verify tokens
var config = require('../../config'); // get our config file

var utility = require('../Utility/Utility');
function verifyToken(req, res, next) {
    //console.log(req.params);
  // check header or url parameters or post parameters for token
  //var token = req.headers['x-access-token'];
    var token = req.headers['authorization'];
    //console.log(token);
    if (token!=null) {
        // Remove Bearer from string
        token = token.slice(7, token.length);
    }
  //console.log(token);
  if (!token) 
    //return res.status(403).send({ auth: false, message: 'No token provided.' });
    return utility.errorResponse(res, 'No token provided.',null);

  // verifies secret and checks exp
  jwt.verify(token, config.secret, function(err, decoded) {      
    if (err) 
      //return res.status(500).send({ auth: false, message: 'Failed to authenticate token.' });    
      return utility.errorResponse(res, 'Failed to authenticate token.',err);
    // if everything is good, save to request for use in other routes
    req.email = decoded.email;
    next();
  });

}

module.exports = verifyToken;