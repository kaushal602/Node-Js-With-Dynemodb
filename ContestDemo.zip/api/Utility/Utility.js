module.exports = {
    successResponse : function (res,message,data) {
        var json = JSON.stringify(data);
        var dataarray = {
            Type: "Success",
            Message: message,
            Data: JSON.parse(json)
        };
        res.status(200).send(dataarray);
    },
    errorResponse : function (res,message,err) {
        var dataarray = {
            Type: "Error",
            Message: message,
            Data: err
        };
        res.status(200).send(dataarray);
    },
    authSuccessResponse : function (res,message,token,data) {
        var dataarray = {
            Type: "Success",
            auth: message,
            token: token,
            Data: data.Item
        };
        res.status(200).send(dataarray);
    },
    authFailResponse: function(res, message,token, data) {
        var dataarray = {
            Type: "Error",
            Message: message,
            token: token,
            Data: data
        };
        res.status(200).send(dataarray);
    },
    errorlog: function(error,routername,functionname,reqvalue){
    //     const fs = require('fs');
    //     var filename = 'errorLogFile.log';
    //     var wstream = null;
    //     //if (!fs.existsSync(filename)) {
    //         wstream = fs.createWriteStream(filename, {'flags': 'a'});
    //    // } 
    //     //wstream = fs.appendFileSync(filename);
    //     wstream.write('\r\nLog Start...');
       
    //     var logtime = new Date();
    //     wstream.write('['+logtime+']:'+error+'\r\n');
    //     wstream.end('Log End...');
        const { createLogger, format, transports } = require('winston');
        require('winston-daily-rotate-file');
        const fs = require('fs');
        const path = require('path');
        const logDir = 'log';
        if (!fs.existsSync(logDir)) {
            fs.mkdirSync(logDir);
        }
          
        //const filename = path.join(logDir, 'errorLogFile.log');
        const dailyRotateFileTransport = new transports.DailyRotateFile({
            filename: `${logDir}/%DATE%-errorlog.log`,
            datePattern: 'YYYY-MM-DD'
          });
        const logger = createLogger({
        // change level if in dev environment versus production
            level: 'debug',
            format: format.combine(
                format.timestamp({
                format: 'YYYY-MM-DD HH:mm:ss'
                }),
                format.printf(info => `${info.timestamp} : ${routername}, ${functionname},${error}, ${reqvalue}`)
            ),
            transports: [
                new transports.Console({
                level: 'debug',
                format: format.combine(
                    format.colorize(),
                    format.printf(
                    info => `${info.timestamp} : ${routername}, ${functionname},${error}, ${reqvalue}`
                    )
                )
                }),
                //new transports.File({ filename })
                dailyRotateFileTransport
            ]
        });
        logger.info(error);
        //logger.warn(error);
//logger.debug('Debugging info');
    }
};