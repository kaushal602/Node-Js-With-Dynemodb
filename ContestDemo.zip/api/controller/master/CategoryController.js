var express = require('express');
var modelCategory = require('../../model/Category');
var utility = require('../../Utility/Utility');
require('dotenv').config();
var AWS = require("aws-sdk");
//multer = require('multer'),
//multerS3 = require('multer-s3');
AWS.config.update({
  region: process.env.region,
  accessKeyId: process.env.aws_access_key_id,
  secretAccessKey: process.env.aws_secret_access_key,
  //endpoint: "http://192.168.1.26:8000/shell/"
});
var dynamodb = new AWS.DynamoDB();
//const fs = require('fs');
//var wstream = fs.createWriteStream('errorLogFile.log');
//var logtime = new Date();
//>>>  JP:[20-Sep-2018] Get all Categories
exports.category_get_all = (req, res) => {
    try {
        md = req.body;
        var params = {
            TableName: process.env.CATEGORY_TABLE,
            FilterExpression: "IsActive = :IsActive",
            //FilterExpression: "Con_Status = :Con_Status",
            ExpressionAttributeValues: {
                ":IsActive": { N: '1' },
            },
        };
        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'category','category_get_all',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data.Items)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'category','category_get_all',JSON.stringify(req.body));
    }
	
}
exports.category_get_all_adminside = (req, res) => {
    try {
        md = req.body;
        var params = {
            TableName: process.env.CATEGORY_TABLE
        };
        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'category','category_get_all',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data.Items)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'category','category_get_all',JSON.stringify(req.body));
    }
	
}
exports.category_get_by_id = (req, res) => {
    try {
 //single get
        md = req.params;
        //console.log(md.id);
        var params = {
            TableName: process.env.CATEGORY_TABLE,
            FilterExpression: "CategoryHashTag = :CategoryHashTag",
            ExpressionAttributeValues: {
                ":CategoryHashTag": { S: md.id}
            },
            //ProjectionExpression: "FirstName,LastName,Email,PhoneNumber",
        };
        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'category','category_get_all',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'category','category_get_all',JSON.stringify(req.body));
    }
}


exports.category_insert = (req, res) => {
  //Validation Check
    try {
        
        //wstream.write('['+logtime+']: '+req.body+'\r\n');
        var md = modelCategory.requestCategory;
        md = req.body;
        var CategoryHashName_TC = md.CategoryHashName_TC.trim();
        CategoryHashName_TC = CategoryHashName_TC.replace(/\s+/g, '_');
        if (!CategoryHashName_TC)
            return utility.errorResponse(res, 'No CategoryHashName_TC provided.',null);
        var CategoryName_TC = md.CategoryName_TC.trim();
        if (!CategoryName_TC) 
            return utility.errorResponse(res, 'No CategoryName_TC  provided..',null);
        var CategoryName = md.CategoryName.trim();
        if (!CategoryName) 
            return utility.errorResponse(res, 'No CategoryName provided.',null);
        var CategoryHashName = md.CategoryHashName.trim();
        CategoryHashName = CategoryHashName.replace(/\s+/g, '_');
        if (!CategoryHashName) 
            return utility.errorResponse(res, 'No CategoryHashName provided.',null);
        
        var params = {
            TableName: process.env.CATEGORY_TABLE,
            FilterExpression: "CategoryHashTag_TC = :CategoryHashTag_TC",
            ExpressionAttributeValues: { ":CategoryHashTag_TC": { S: CategoryHashName_TC} },
        };
        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'category','category_insert',JSON.stringify(req.body));
            } else {
                //console.log(data);
                //console.log(data.Items.length);
                //utility.successResponse(res, 'Success', data)
                if(data.Count>0){
                    return utility.errorResponse(res, 'CategoryHashName Already Exiest.',null);
                } else {
                    var params = {
                        TableName: process.env.CATEGORY_TABLE,
                        FilterExpression: "CategoryHashTag = :CategoryHashName",
                        ExpressionAttributeValues: { ":CategoryHashName": { S: CategoryHashName} },
                    };
                    dynamodb.scan(params, function (err, catdata) {
                        if (err) {
                            utility.errorResponse(res, 'error', err);
                            utility.errorlog(err.stack,'category','category_insert',JSON.stringify(req.body));
                        } else {
                            //console.log(catdata);
                            //utility.successResponse(res, 'Success', catdata)
                            if(catdata.Count>0){
                                return utility.errorResponse(res, 'Category Name Already Exiest.',null);
                                //return res.status(200).send({ auth: false, message: 'CategoryHashName Already Exiest.' });
                            } else {
                                var CategoryImage = 'N/A';
                                if(md.CategoryImage!=''){
                                    singleImg = new Buffer(md.CategoryImage.replace(/^data:image\/\w+;base64,/, ""),'base64');
                                    var bucketFolder = process.env.S3_BUCKET_NAME;
                                    var singleimgFolder = bucketFolder + '/categoryimage';
                                    var bucket = new AWS.S3({
                                        params: {
                                            Bucket: singleimgFolder
                                        }
                                    });
                                    var currentdate = new Date().getTime().toString();
                                    var imgname = currentdate+md.CategoryImageName;
                                    var contentToPost = {
                                        Key: imgname, 
                                        Body: singleImg,
                                        ACL: 'public-read',
                                        ContentEncoding: 'base64'
                                    };
                                    //ContestImagePath = singleimgFolder+'/'+imgname;
                                    CategoryImage = imgname;
                                    bucket.putObject(contentToPost, function (error, data) {
                                        if (error) { return false;
                                        } 
                                        else {} 
                                    })
                                    .on('httpUploadProgress',function (progress) {
                                        //console.log(Math.round(progress.loaded / progress.total * 100) + '% done');
                                    });
                                }
                                var params = {
                                    TableName: process.env.CATEGORY_TABLE,
                                    Item:{
                                        CategoryHashTag_TC:  { S: CategoryHashName_TC },
                                        CategoryHashTag: { S: CategoryHashName },
                                        CategoryName: { S: CategoryName },
                                        CategoryName_TC: { S: CategoryName_TC },
                                        CategoryImage:{ S: CategoryImage },
                                        IsActive:{ N: "1"}
                                    }
                                };

                                dynamodb.putItem(params, function(err, data) {
                                    if (err) {
                                        utility.errorResponse(res, 'error', err);
                                        utility.errorlog(err.stack,'category','category_insert',JSON.stringify(req.body));
                                    } else {
                                        utility.successResponse(res, 'Success', data)
                                    }
                                });
                            }
                        }
                    });
                }
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'category','category_insert',JSON.stringify(req.body));
    }
}

// exports.chinese_category_insert = (req, res) => {
//     //Validation Check
//     try {
        
//         var md = modelCategory.requestCategory;
//         md = req.body;
//         var CategoryHashTag_TC = md.CategoryHashTag_TC;
//         if (!CategoryHashTag_TC) 
//             return res.status(403).send({ auth: false, message: 'No CategoryHashTag_TC provided.' });
//         var CategoryName_TC = md.CategoryName_TC;
//         if (!CategoryName_TC) 
//             return res.status(403).send({ auth: false, message: 'No CategoryName_TC  provided.' });
//         var CategoryImage = md.CategoryImage;
//         if (!CategoryImage) 
//             return res.status(403).send({ auth: false, message: 'No CategoryImage provided.' });
        
//     //Insert Data
//         var params = {
//             TableName: process.env.CATEGORY_TABLE,
//             Item:{
//                 //CategoryHashTag: { S: md.CategoryHashTag },
//                 CategoryHashTag_TC:  { S: md.CategoryHashTag_TC },
//                 //CategoryName: { S: md.CategoryName },
//                 CategoryName_TC: { S: md.CategoryName_TC },
//                 CategoryImage:{ S: md.CategoryImage },
//                 IsActive:{ N: "1"}
//             }
//         };

//         dynamodb.putItem(params, function(err, data) {
//             if (err) {
//                 utility.errorResponse(res, 'error', err);
//                 utility.errorlog(err.stack,'category','category_insert',JSON.stringify(req.body));
//             } else {
//                 utility.successResponse(res, 'Success', data)
//             }
//         });
//     } catch (err) {
//         utility.errorlog(err.stack,'category','category_insert',JSON.stringify(req.body));
//     }
// }

exports.category_update = (req, res) => {
    try {
    //Validation Check
        //console.log('as');
        md = req.body;
        //console.log(md);
        var CategoryHashName_TC = md.CategoryHashName_TC.trim();
        CategoryHashName_TC = CategoryHashName_TC.replace(/\s+/g, '_');
        if (!CategoryHashName_TC)
            return utility.errorResponse(res, 'No CategoryHashName_TC provided.',null);
        var CategoryName_TC = md.CategoryName_TC.trim();
        if (!CategoryName_TC) 
            return utility.errorResponse(res, 'No CategoryName_TC  provided..',null);
        var CategoryName = md.CategoryName.trim();
        if (!CategoryName) 
            return utility.errorResponse(res, 'No CategoryName provided.',null);
        var CategoryHashName = md.CategoryHashName.trim();
        CategoryHashName = CategoryHashName.replace(/\s+/g, '_');
        if (!CategoryHashName) 
            return utility.errorResponse(res, 'No CategoryHashName provided.',null);

        var CategoryImage = 'N/A';
        if(md.CategoryImage!=''){
            singleImg = new Buffer(md.CategoryImage.replace(/^data:image\/\w+;base64,/, ""),'base64');
            var bucketFolder = process.env.S3_BUCKET_NAME;
            //var subdir = id;
            var singleimgFolder = bucketFolder + '/categoryimage';
            var bucket = new AWS.S3({
                params: {
                    Bucket: singleimgFolder
                }
            });
            var currentdate = new Date().getTime().toString();
            var imgname = currentdate+md.CategoryImageName;
            var contentToPost = {
                Key: imgname, 
                Body: singleImg,
                ACL: 'public-read',
                ContentEncoding: 'base64'
            };
            //ContestImagePath = singleimgFolder+'/'+imgname;
            CategoryImage = imgname;
            bucket.putObject(contentToPost, function (error, data) {
                if (error) {
                    return false;
                }else {
                } 
            })
            .on('httpUploadProgress',function (progress) {
                //console.log(Math.round(progress.loaded / progress.total * 100) + '% done');
            });
        } else {
            CategoryImage = md.catimage;
        }
       
        
        var params = {
            Key: {
                CategoryHashTag_TC : { S:md.CategoryHashName_TC}
            },
            TableName: process.env.CATEGORY_TABLE,
            UpdateExpression: "set CategoryName = :CategoryName, CategoryName_TC = :CategoryName_TC, CategoryImage = :CategoryImage",
            ExpressionAttributeValues:{
                //":CategoryHashTag":{ S:md.CategoryName},
                //":CategoryHashTag_TC":{ S:md.CategoryHashTag_TC},
                ":CategoryName":{ S:CategoryName},
                ":CategoryName_TC":{ S:CategoryName_TC},
                ":CategoryImage":{ S:CategoryImage},
            },
            ReturnValues:"UPDATED_NEW"
        };
        dynamodb.updateItem(params, function(err, data) {
            if (err) {        
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'category','category_update',JSON.stringify(req.body));
            } else {        
                utility.successResponse(res, 'Success', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'category','category_update',JSON.stringify(req.body));
    }
}

exports.category_statuschange = (req, res) => {
    try {
    //Delete Call
        md=req.body;
        //console.log(md);
        var params = {
        	Key: {
        		CategoryHashTag_TC: {S: md.categoryhastag}
        	},
        	TableName: process.env.CATEGORY_TABLE,
        	UpdateExpression: "set IsActive = :IsActive",
        	ExpressionAttributeValues: {
        		":IsActive": {N: md.Status},
        	},
        	ReturnValues: "UPDATED_NEW"
        };
        dynamodb.updateItem(params, function (err, data) {
        	if (err) {
        		utility.errorResponse(res, 'error', err);
        	} else {
        		utility.successResponse(res, 'Success', data)
        	}
        });
        
    } catch (err) {
        utility.errorlog(err.stack,'category','category_delete',JSON.stringify(req.body));
    }
}


exports.category_delete = (req, res) => {
    try {
    //Delete Call
        // var params = {
        // 	Key: {
        // 		CategoryHashTag: {
        // 		S: req.params.id
        // 		}
        // 	},
        // 	TableName: process.env.CATEGORY_TABLE,
        // 	UpdateExpression: "set IsActive = :IsActive",
        // 	ExpressionAttributeValues: {
        // 		":IsActive": {
        // 		N: "0"
        // 		},
        // 	},
        // 	ReturnValues: "UPDATED_NEW"
        // };
        // dynamodb.updateItem(params, function (err, data) {
        // 	if (err) {
        // 		utility.errorResponse(res, 'error', err);
        // 	} else {
        // 		utility.successResponse(res, 'Success', data)
        // 	}
        // });
        var params = {
            Key: {
                CategoryHashTag_TC : { S:req.params.id}
            },
            TableName: process.env.CATEGORY_TABLE
        };
        dynamodb.deleteItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'category','category_delete',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'category','category_delete',JSON.stringify(req.body));
    }
}

exports.category_image = (req, res) => {
    //console.log(req.body);
    
    
    // buf = new Buffer(req.body.imageBinary.replace(/^data:image\/\w+;base64,/, ""),'base64');
    // //buf = new Buffer.allocUnsafe(req.body.imageBinary.replace('/^data:video\/\w+;base64,/', ""),'base64')
    // var bucketFolder = 'contest888-images';
    // var subdir = '11122';
    // var userFolder = bucketFolder + '/' + subdir;

    // var bucket = new AWS.S3({
    //     params: {
    //         Bucket: userFolder
    //     }
    // });
    // var contentToPost = {
    //     Key:  'success12342.png', 
    //     Body: buf,
    //     ACL: 'public-read',
    //     ContentEncoding: 'base64'
    // };

    // bucket.putObject(contentToPost, function (error, data) {

    //     if (error) {
    //         console.log("Error in posting Content [" + error + "]");
    //         return false;
    //     } /* end if error */
    //     else {
    //         console.log("Successfully posted Content 123");
    //     } /* end else error */
    // })
    // .on('httpUploadProgress',function (progress) {
    //     // Log Progress Information
    //     console.log(Math.round(progress.loaded / progress.total * 100) + '% done');
    // });
}
