var express = require('express');
var modelCategory = require('../../model/Category');
var utility = require('../../Utility/Utility');
require('dotenv').config();
var AWS = require("aws-sdk");
AWS.config.update({
  region: process.env.region,
  accessKeyId: process.env.aws_access_key_id,
  secretAccessKey: process.env.aws_secret_access_key,
  //endpoint: "http://192.168.1.26:8000/shell/"
});
var dynamodb = new AWS.DynamoDB();

//>>>  JP:[20-Sep-2018] Get all Categories
exports.country_get_all = (req, res) => {
    try {
	//var md = modelCategory.requestCategory;
        md = req.body;
        //console.log(JSON.stringify(md,null,2));
        //res.send(req.params.id);
        var params = {
            TableName: process.env.COUNTRY_TABLE,
            FilterExpression: "IsActive = :IsActive",
            ExpressionAttributeValues: {
                ":IsActive": { N: '1' },
            },
        };
        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'country','country_get_all',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data.Items)
                //res.status(200).send("Success: " + "\n" + JSON.stringify(data));
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'country','country_get_all',JSON.stringify(req.body));
    }
	
}

exports.country_get_adminside = (req, res) => {
    try {
	//var md = modelCategory.requestCategory;
        md = req.body;
        //console.log(JSON.stringify(md,null,2));
        //res.send(req.params.id);
        var params = {
            TableName: process.env.COUNTRY_TABLE,
        };
        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'country','country_get_all',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data.Items)
                //res.status(200).send("Success: " + "\n" + JSON.stringify(data));
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'country','country_get_all',JSON.stringify(req.body));
    }
	
}
exports.country_get_by_id = (req, res) => {
    try {
 //single get
        var params = {
        TableName: process.env.COUNTRY_TABLE,
        Key: {
            'CountryCode': { S: req.params.id },
        },
        };
        dynamodb.getItem(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'country','country_get_by_id',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'country','country_get_by_id',JSON.stringify(req.body));
    }
}


exports.country_insert = (req, res) => {
    try {
  //Validation Check
        var md = modelCategory.requestCategory;
        md = req.body;
        //console.log(md);
        var CountryCode = md.CountryIsoCode;
        if (!CountryCode) 
            return res.status(403).send({ auth: false, message: 'No CountryCode provided.' });
        var CountryName = md.CountryName;
        if (!CountryName) 
            return res.status(403).send({ auth: false, message: 'No CountryName provided.' });


        var params = {
            TableName: process.env.COUNTRY_TABLE,
            FilterExpression: "CountryCode = :CountryCode",
            ExpressionAttributeValues: { ":CountryCode": { S: CountryCode} },
        };
        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'category','category_insert',JSON.stringify(req.body));
            } else {
                if(data.Count>0){
                    return utility.errorResponse(res, 'Country Already Exiest.',null);
                } else {
                    var params = {
                    TableName: process.env.COUNTRY_TABLE,
                        Item:{
                            CountryCode: { S: CountryCode },
                            CountryName: { S: CountryName },
                            IsActive:{ N: "1"}
                        }
                    };
            
                    dynamodb.putItem(params, function(err, data) {
                        if (err) {
                            utility.errorResponse(res, 'error', err);
                            utility.errorlog(err.stack,'country','country_insert',JSON.stringify(req.body));
                        } else {
                            utility.successResponse(res, 'Success', data)
                        }
                    });
                }
            }
        });
    //Insert Data
        
    } catch (err) {
        utility.errorlog(err.stack,'country','country_insert',JSON.stringify(req.body));
    }
}

exports.country_update = (req, res) => {
    try {
	//Validation Check
        var md = modelCategory.requestCategory;
        md = req.body;
        var CountryName = md.CountryName.trim();
        if (!CountryName)
        return res.status(403).send({auth: false, message: 'No CountryName provided.'});

        //Call update Method
        var params = {
            Key: {
                CountryCode : { S:md.CountryIsoCode}
            },
            TableName: process.env.COUNTRY_TABLE,
            UpdateExpression: "set CountryName = :CountryName",
            ExpressionAttributeValues:{
                ":CountryName":{ S:CountryName}
            },
            ReturnValues:"UPDATED_NEW"
        };
        dynamodb.updateItem(params, function(err, data) {
            if (err) {        
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'country','country_update',JSON.stringify(req.body));
            } else {        
                utility.successResponse(res, 'Success', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'country','country_update',JSON.stringify(req.body));
    }
}

exports.country_statuschange = (req, res) => {
    try {
  //Delete Call
        md=req.body;
        var params = {
            Key: {
                CountryCode: { S: md.CountryCode }
            },
            TableName: process.env.COUNTRY_TABLE,
            UpdateExpression: "set IsActive = :IsActive",
            ExpressionAttributeValues: {
                ":IsActive": { N: md.Status },
            },
            ReturnValues: "UPDATED_NEW"
        };
        dynamodb.updateItem(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'country','country_delete',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'country','country_delete',JSON.stringify(req.body));
    }
}
exports.country_delete = (req, res) => {
    try {
  //Delete Call
        var params = {
            Key: {
                CountryCode : { S:req.params.id}
            },
            TableName: process.env.COUNTRY_TABLE
        };
        dynamodb.deleteItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
            } else {
                utility.successResponse(res, 'Success', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'country','country_delete',JSON.stringify(req.body));
    }
	// var params = {
	// 	Key: {
	// 		CountryCode : { S:req.params.id}
	// 	},
	// 	TableName: process.env.COUNTRY_TABLE
	// };
	// dynamodb.deleteItem(params, function(err, data) {
	// 	if (err) {
	// 		utility.errorResponse(res, 'error', err);
	// 	} else {
	// 		utility.successResponse(res, 'Success', data)
	// 	}
	// });
}
