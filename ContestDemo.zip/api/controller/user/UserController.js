var express = require('express');
var modelCategory = require('../../model/Category');
var utility = require('../../Utility/Utility');
var VerifyToken = require('../../auth/VerifyToken');
const uuid = require('uuid');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var config = require('../../../config');
require('dotenv').config();

var nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');
var handlebars = require('handlebars');
var fs = require('fs');
var readHTMLFile = function(path, callback) {
    fs.readFile(path, {encoding: 'utf-8'}, function (err, html) {
        if (err) {
            throw err;
            callback(err);
        }
        else {
            callback(null, html);
        }
    });
};
smtpTransport = nodemailer.createTransport(smtpTransport({
    service: 'gmail',
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_USER_PASS
    }
}));


var AWS = require("aws-sdk");
AWS.config.update({
  region: process.env.region,
  accessKeyId: process.env.aws_access_key_id,
  secretAccessKey: process.env.aws_secret_access_key,
  //endpoint: "http://192.168.1.26:8000/shell/",
});
var dynamodb = new AWS.DynamoDB();


exports.user_create = (req, res) => {
    const id = uuid.v1();
    try {
        md = req.body;
        //console.log(md);
        var Email = md.Email;
        if (!Email) {
            return utility.errorResponse(res, 'No Email provided.',null);
        }
        var FirstName = md.FirstName;
        if (!FirstName) {
            return utility.errorResponse(res, 'No FirstName provided.',null);
        }
        var LastName = md.LastName;
        if (!LastName) {
            return utility.errorResponse(res, 'No LastName provided.',null);
        }
    
        var Password = md.Password;
        if (!Password) {
            return utility.errorResponse(res, 'No Password provided.',null);
        }
        var currentdate = new Date().getTime().toString();   
        var params = {
            TableName: process.env.USER_TABLE,
            Key: {
                'Email' : {S: req.body.Email},
            },
        };
        dynamodb.getItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','user_create',JSON.stringify(req.body));
            } else {
                //utility.successResponse(res, 'Success', data);
                //console.log(data);
                if(JSON.stringify(data) === '{}'){
                    var params = {
                        TableName: process.env.USER_TABLE,
                        Item:{
                            Id : { S : id },
                            Email : { S : md.Email },
                            Password :{ S : bcrypt.hashSync(md.Password) },
                            FirstName : { S : md.FirstName },
                            LastName : { S : md.LastName },
                            CountryCode : { S : md.PhoneNumber },
                            PhoneNumber : { S : md.PhoneNumber},
                            WhatsappNumber : { S : md.WhatsappNumber},
                            UserType : { S : md.UserType},
                            IsActive : { S : '1' },
                            CompanyName : { S : md.CompanyName},
                            PrefferedLang : { S : md.PrefferedLang },
                            CreatedDate : { N : currentdate },
                            ModifiedDate : { N : currentdate }
                        }
                    };
            
                    dynamodb.putItem(params, function(err, data) {
                        if (err) {
                            utility.errorResponse(res, 'error2', err);
                            utility.errorlog(err.stack,'user','user_create',JSON.stringify(req.body));
                        } else {
                            /************* Email Send Start ************/
                            readHTMLFile(__dirname + '/email.html', function(err, html) {
                                var template = handlebars.compile(html);
                                var replacements = {
                                    name: FirstName
                                };
                                var htmlToSend = template(replacements);
                                var mailOptions = {
                                    from: 'Contest888 <info@contest888.com>',
                                    to : Email,
                                    subject : 'User registration successfully',
                                    html : htmlToSend
                                    };
                                smtpTransport.sendMail(mailOptions, function (error, response) {
                                    if (error) {
                                        //console.log(error);
                                        utility.errorlog(err,'user','user_create',JSON.stringify(error));
                                        //callback(error);
                                    }
                                    if(response){
                                        utility.errorlog(err,'user','user_create',JSON.stringify(response));
                                        //console.log(response);
                                    }
                                });
                            });
                            /*********** Email Send End*********/
                            var params = {
                                TableName: process.env.USER_TABLE,
                                Key: {
                                    'Email' : {S: md.Email},
                                },
                            };
                            dynamodb.getItem(params, function(err, userdata) {
                                var token = jwt.sign({ Email: userdata.Item.Email }, config.secret, {
                                    expiresIn: 86400 
                                });
                                utility.authSuccessResponse(res, 'true',token, userdata);
                            });
                        }
                    });
                } else {
                    utility.errorResponse(res, 'error1', err);
                    utility.errorlog(err,'user','user_create',JSON.stringify(req.body));
                }
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','user_create',JSON.stringify(req.body));
    }
}

exports.delete_user = (req, res) => {
    try {
        TableName=process.env.USER_TABLE;
        var params = {
            Key: {
                'Email' : {S: req.body.Email},
            },
            TableName: TableName
        };
        dynamodb.deleteItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','delete_user',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','delete_user',JSON.stringify(req.body));
    }
}


exports.user_update = (req, res) => {
    try {
        const id = uuid.v1();
        md = req.body;
        var Email = md.Email;
        if (!Email) {
            return utility.errorResponse(res, 'No Email provided.',null);
        }
        var FirstName = md.FirstName;
        if (!FirstName) {
            return utility.errorResponse(res, 'No FirstName provided.',null);
        }
        var LastName = md.LastName;
        if (!LastName) {
            return utility.errorResponse(res, 'No LastName provided.',null);
        }
    
        var params = {
            TableName: process.env.USER_TABLE,
            Key: {
                'Email' : {S: md.Email},
            },
            UpdateExpression: "set FirstName = :FirstName,LastName = :LastName,CountryCode = :CountryCode,PhoneNumber = :PhoneNumber,WhatsappNumber = :WhatsappNumber,PrefferedLang = :PrefferedLang",
            ExpressionAttributeValues:{
                ":FirstName" : { S : md.FirstName },
                ":LastName" : { S : md.LastName },
                ":CountryCode" : { S : md.CountryCode },
                ":PhoneNumber" : { S : md.PhoneNumber },
                ":WhatsappNumber" : { S : md.WhatsappNumber },
                ":PrefferedLang" : { S : md.PreferLanguage }
            },
            ReturnValues:"ALL_NEW"
        };

        dynamodb.updateItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','user_update',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','user_update',JSON.stringify(req.body));
    }
}
exports.forgot_password_email = (req, res) => {
    md = req.body;
    var params = {
        TableName: process.env.USER_TABLE,
        Key: {
            'Email' : {S: req.body.Email},
        },
    };
    dynamodb.getItem(params, function(err, data) {
        if (err) {
            utility.errorResponse(res, 'error', err);
            utility.errorlog(err.stack,'user','user_create',JSON.stringify(req.body));
        } else {
            //utility.successResponse(res, 'Success', data);
            //console.log(data);
            if(JSON.stringify(data) != '{}'){
                        /************* Email Send Start ************/
                    var uesremail = req.body.Email;  
                    var buff = new Buffer(uesremail);  
                    var base64data = buff.toString('base64');
                    readHTMLFile(__dirname + '/forgotemail.html', function(err, html) {
                        var template = handlebars.compile(html);
                        var replacements = {
                            email: base64data,
                            name: data.Item.FirstName.S,
                            Baseurl:md.Baseurl
                        };
                        var htmlToSend = template(replacements);
                        var mailOptions = {
                            from: 'Contest888 <info@contest888.com>',
                            to : req.body.Email,
                            subject : 'Contest888 Forgot Password Email',
                            html : htmlToSend
                            };
                        smtpTransport.sendMail(mailOptions, function (error, response) {
                            if (error) {
                                //console.log(error);
                                utility.errorResponse(res, 'error', error);
                                utility.errorlog(err,'user','user_create',JSON.stringify(error));
                                //callback(error);
                            }
                            if(response){
                                //utility.successResponse(res, 'Success', response);
                                var params = {
                                    TableName: process.env.USER_TABLE,
                                    Key: {
                                        'Email' : {S: req.body.Email},
                                    },
                                    UpdateExpression: "set IsChangePassword = :IsChangePassword",
                                    ExpressionAttributeValues:{
                                        ":IsChangePassword" : { N : '0' }
                                    },
                                    ReturnValues:"ALL_NEW"
                                };
                        
                                dynamodb.updateItem(params, function(err, data) {
                                    if (err) {
                                        utility.errorResponse(res, 'error', err);
                                        utility.errorlog(err.stack,'user','user_update',JSON.stringify(req.body));
                                    } else {
                                        utility.successResponse(res, 'Success', data)
                                    }
                                });
                                //console.log(response);
                            }
                        });
                    });
                    /*********** Email Send End*********/
            } else {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err,'user','user_create',JSON.stringify(req.body));
            }
        }
    });
}

exports.forgot_password_change = (req, res) => {
    try {
        md = req.body;
        //console.log(md);
        var Email = md.Email;
        let UserEmail = md.UserId;  
        let buff = new Buffer(UserEmail, 'base64');  
        let email = buff.toString('ascii');

        var params = {
            TableName: process.env.USER_TABLE,
            Key: {
                'Email' : {S: email},
            },
        };
        dynamodb.getItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','get_user_detail',JSON.stringify(req.body));
            } else {
                console.log(data.Item.IsChangePassword.N);
                
                //console.log(data.Item);
                
                if(data.Item.IsChangePassword.N=='0'){
                    console.log('in');
                    var params = {
                        TableName: process.env.USER_TABLE,
                        Key: {
                            'Email' : {S: email},
                        },
                        UpdateExpression: "set Password = :Password, IsChangePassword = :IsChangePassword",
                        ExpressionAttributeValues:{
                            ":Password" : { S : bcrypt.hashSync(md.Password) },
                            ":IsChangePassword" : { N : '1' }
                        },
                        ReturnValues:"ALL_NEW"
                    };
            
                    dynamodb.updateItem(params, function(err, data) {
                        if (err) {
                            utility.errorResponse(res, 'error', err);
                            utility.errorlog(err.stack,'user','forgot_password_change',JSON.stringify(req.body));
                        } else {
                            utility.successResponse(res, 'Success', data)
                        }
                    });
                } else {
                    utility.errorResponse(res, 'ResetError', data);
                }
            }
        });
        
    } catch (err) {
        utility.errorlog(err.stack,'user','forgot_password_change',JSON.stringify(req.body));
    }
}
exports.check_forgot_password_link = (req, res) => {
    try {
        md = req.body;
        //console.log(md);
        var Email = md.Email;
        let UserEmail = md.UserId;  
        let buff = new Buffer(UserEmail, 'base64');  
        let email = buff.toString('ascii');

        var params = {
            TableName: process.env.USER_TABLE,
            Key: {
                'Email' : {S: email},
            },
        };
        dynamodb.getItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','check_forgot_password_link',JSON.stringify(req.body));
            } else {
                console.log(data.Item.IsChangePassword.N);                
                if(data.Item.IsChangePassword.N=='0'){
                    utility.successResponse(res, 'Success', data)
                } else {
                    utility.successResponse(res, 'ResetError', data);
                }
            }
        });
        
    } catch (err) {
        utility.errorlog(err.stack,'user','check_forgot_password_link',JSON.stringify(req.body));
    }
}

exports.get_all_user = (req, res) => {
    try {
        var params = {
            TableName: process.env.USER_TABLE,
        };
        dynamodb.scan(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','get_all_user',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','get_all_user',JSON.stringify(req.body));
    }
}
exports.get_organizer_list = (req, res) => {
    try {
        var params = {
            TableName: process.env.USER_TABLE,
            FilterExpression: "UserType = :UserType",
            ExpressionAttributeValues: {
                ":UserType": { S: 'O' }
            },
        };
        dynamodb.scan(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','get_organizer_list',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','get_organizer_list',JSON.stringify(req.body));
    }
}
exports.get_user_detail = (req, res) => {
    try {
        var params = {
            TableName: process.env.USER_TABLE,
            Key: {
                'Email' : {S: req.body.Email},
            },
        };
        dynamodb.getItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','get_user_detail',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data);
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','get_user_detail',JSON.stringify(req.body));
    }
}
exports.get_user_detail_by_id = (req, res) => {
    try {
        md = req.body;
        var params = {
            TableName: process.env.USER_TABLE,
            FilterExpression: "Id = :Id",
            ExpressionAttributeValues: {
                ":Id": { S: md.Userid}
            },
            ProjectionExpression: "FirstName,LastName,Email,PhoneNumber",
        };
        dynamodb.scan(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','get_user_detail_by_id',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','get_user_detail_by_id',JSON.stringify(req.body));
    }
}
exports.get_child_detail_by_id = (req, res) => {
    try {
        md = req.body;
        //console.log(md.ChildId);
        var params = {
            TableName: process.env.PARTICIPANT,
            Key: {
                'Id' : {S: req.body.ChildId},
            },
        };
        dynamodb.getItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','get_child_detail_by_id',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data);
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','get_child_detail_by_id',JSON.stringify(req.body));
    }
}
exports.user_addtowishlist = (req, res) => {
    try {
        const id = uuid.v1();
        md = req.body;
        var UserId = md.UserId;
        if (!UserId) {
            return utility.errorResponse(res, 'No UserId provided.',null);
        }
        var ContestId = md.ContestId;
        if (!ContestId) {
            return utility.errorResponse(res, 'No ContestId provided.',null);
        }
        var ContestLang = md.ContestLang;
        if (!ContestLang) {
            return utility.errorResponse(res, 'No ContestLang provided.',null);
        }

        var CurrentDate = new Date().getTime().toString();   
        
        var params = {
            TableName: process.env.USER_WISHLIST,
            Item:{
                Id : { S : id },
                UserId : { S : UserId },
                ContestId :{ S : ContestId },
                ContestLang :{ S : ContestLang },
                CreatedDate : { S : CurrentDate }
            }
        };
        
        dynamodb.putItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','user_addtowishlist',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data);
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','user_addtowishlist',JSON.stringify(req.body));
    }
}

exports.user_removewishlist = (req, res) => {
    try {
        md = req.body;
        var Id = md.WishlistId;
        if (!Id) {
            return utility.errorResponse(res, 'No Id provided.',null);
        }
        
        var params = {
            Key: {
                Id : { S: md.WishlistId }
            },
            TableName: process.env.USER_WISHLIST
        };
        dynamodb.deleteItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','user_removewishlist',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','user_removewishlist',JSON.stringify(req.body));
    }
}
exports.get_wishlist_contest = (req, res) => {
    try {
        md = req.body;
        var params = {
            TableName: process.env.USER_WISHLIST,
            FilterExpression: "UserId = :UserId AND ContestLang = :ContestLang",
            ExpressionAttributeValues: {
                ":UserId": { S: md.UserId},
                ":ContestLang": { S : md.DefaultLang}
            },
            ProjectionExpression: "ContestId,ContestLang",
        };
        dynamodb.scan(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','get_wishlist_list',JSON.stringify(req.body));
            } else {
                
                //console.log(data.Items.length);
                if(data.Items.length>0){
                    var allContest = '';
                    var filterExpression =  ""; 
                    var expressionAttributeValues = {};
                    catfilterexp = '(';
                    for(var i=0; i<data.Items.length; i++){
                        var contentIdName = ":Id"+(i+1);
                        if (i==0) {
                            catfilterexp = catfilterexp +'contains (Id,'+ contentIdName+')';
                        } else {
                            catfilterexp = catfilterexp + " OR " +'contains (Id,'+ contentIdName+')';
                        }
                        expressionAttributeValues[contentIdName] ={ S: data.Items[i].ContestId.S};
                    }
                    catfilterexp =catfilterexp +')';
                    //console.log(catfilterexp);
                    //console.log(expressionAttributeValues);
                    if(catfilterexp!=''){
                        if(filterExpression!=''){
                            filterExpression=filterExpression+' AND '+catfilterexp;
                        }else {
                            filterExpression=filterExpression+catfilterexp;
                        }
                    }
                    
                    // var userlang = md.DefaultLang;
                    // if(userlang=='' || userlang== 'null'){
                    //     TableName = process.env.CONTEST_TABLE;
                    // } else {
                    //     if(userlang=='en' || userlang == 'null'){
                    TableName = process.env.CONTEST_TABLE;
                    //     } else {
                    //         TableName = process.env.CONTEST_TABLE_TC;
                    //     } 
                    // }
                    params = {
                        TableName: TableName,
                        ExpressionAttributeValues:expressionAttributeValues,
                        FilterExpression: filterExpression,
                    };
                    dynamodb.scan(params, function (err, data) {
                        if (err) {
                            utility.errorResponse(res, 'error', err);
                            utility.errorlog(err.stack,'contest','search_contest',JSON.stringify(req.body));
                        } else {
                            utility.successResponse(res, 'Success', data.Items);
                        }
                    });
                    
                }
                //utility.successResponse(res, 'Success', data);
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','get_wishlist_list',JSON.stringify(req.body));
    }
}
exports.get_user_wishlist_id = (req, res) => {
    try {
        md = req.params;
        //console.log(md);
        
        var prefLang = req.params.prefLang;
        var UserId = md.userid;
        if (!UserId) {
            return utility.errorResponse(res, 'No UserId provided.',null);
        }
        var params = {
            TableName: process.env.USER_WISHLIST,
            FilterExpression: "UserId = :UserId",
            ExpressionAttributeValues: {
                ":UserId": { S: UserId}
                //":ContestLang": { S : prefLang}
            },
            ProjectionExpression: "Id,ContestId",
        };
        dynamodb.scan(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','get_user_wishlist_id',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','get_user_wishlist_id',JSON.stringify(req.body));
    }
} 
exports.add_participant = (req, res) => {
    try {
        const id = uuid.v1();
        md = req.body;
        var FirstName = md.FirstName;
        if (!FirstName) {
            return utility.errorResponse(res, 'No FirstName provided.',null);
        }
        var LastName = md.LastName;
        if (!LastName) {
            return utility.errorResponse(res, 'No LastName provided.',null);
        }
    
        var UserImagePath = 'N/A';
        var currentdate = new Date().getTime().toString();
        //console.log(md.ContestImage);
        
            if(md.UserImage!=''){
                singleImg = new Buffer(md.UserImage.replace(/^data:image\/\w+;base64,/, ""),'base64');
                var bucketFolder = process.env.S3_BUCKET_NAME;
                var subdir = id;
                var singleimgFolder = bucketFolder + '/userimage/' + subdir;
                var bucket = new AWS.S3({
                    params: {
                        Bucket: singleimgFolder
                    }
                });
                var imgname = currentdate+md.UserImageName;
                var contentToPost = {
                    Key: imgname, 
                    Body: singleImg,
                    ACL: 'public-read',
                    ContentEncoding: 'base64'
                };
                //ContestImagePath = singleimgFolder+'/'+imgname;
                UserImagePath = imgname;
                bucket.putObject(contentToPost, function (error, data) {
                    if (error) {
                        //console.log("Error in posting Content [" + error + "]");
                        return false;
                    } 
                    else {
                        //console.log(data);
                    } 
                })
                .on('httpUploadProgress',function (progress) {
                    //console.log(Math.round(progress.loaded / progress.total * 100) + '% done');
                });
            }
        
         
        var params = {
            TableName: process.env.PARTICIPANT,
            Item:{
                Id : { S : id },
                UserId :{ S : md.UserId },
                FirstName : { S : md.FirstName },
                LastName : { S : md.LastName },
                HKID : { S : UserImagePath },
                Gender : { S : md.Gender},
                Birthday : { S : md.Birthday},
                CurrentGrade : { S : md.CurrentGrade},
                CreatedDate : { N : currentdate },
                ModifiedDate : { N : currentdate }
            }
        };

        dynamodb.putItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','add_participant',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', id)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','add_participant',JSON.stringify(req.body));
    }
}
exports.child_data_update = (req, res) => {
    try {
        md = req.body;
        var FirstName = md.FirstName;
        if (!FirstName) {
            return utility.errorResponse(res, 'No FirstName provided.',null);
        }
        var LastName = md.LastName;
        if (!LastName) {
            return utility.errorResponse(res, 'No LastName provided.',null);
        }
        
        var currentdate = new Date().getTime().toString();
        var UserImagePath = 'N/A';
        //console.log(md.ContestImage);
        if(md.UserImage!=''){
            singleImg = new Buffer(md.UserImage.replace(/^data:image\/\w+;base64,/, ""),'base64');
            var bucketFolder = process.env.S3_BUCKET_NAME;
            var subdir = md.ChildId;
            var singleimgFolder = bucketFolder + '/userimage/' + subdir;
            var bucket = new AWS.S3({
                params: {
                    Bucket: singleimgFolder
                }
            });
            var imgname = currentdate+md.UserImageName;
            var contentToPost = {
                Key: imgname, 
                Body: singleImg,
                ACL: 'public-read',
                ContentEncoding: 'base64'
            };
            //ContestImagePath = singleimgFolder+'/'+imgname;
            UserImagePath = imgname;
            bucket.putObject(contentToPost, function (error, data) {
                if (error) {
                    //console.log("Error in posting Content [" + error + "]");
                    //return false;
                } 
                else {
                    //console.log(data);
                } 
            })
            .on('httpUploadProgress',function (progress) {
                //console.log(Math.round(progress.loaded / progress.total * 100) + '% done');
            });
        } else {
            UserImagePath = md.hkid;
        }

        if(md.DeleteImg!=null){
            if(md.DeleteImg.length>0){
                var bucketFolder = process.env.S3_BUCKET_NAME;
                var subdir = md.ChildId;
                var imageFolder = bucketFolder + '/userimage/' + subdir;
                var bucketInstance = new AWS.S3();
                var params = {
                    Bucket: imageFolder,
                    Key: md.DeleteImg
                };
                bucketInstance.deleteObject(params, function (err, data) {
                    if (data) {
                        console.log("File deleted successfully");
                    }
                    else {
                        console.log("Check if you have sufficient permissions : "+err);
                    }
                });
            }
        }
        var params = {
            TableName: process.env.PARTICIPANT,
            Key: {
                'Id' : {S: md.ChildId},
            },
            UpdateExpression: "set FirstName = :FirstName,LastName = :LastName,Gender = :Gender,Birthday = :Birthday,CurrentGrade = :CurrentGrade,HKID = :HKID,ModifiedDate = :ModifiedDate",
            ExpressionAttributeValues:{
                ":FirstName" : { S : md.FirstName },
                ":LastName" : { S : md.LastName },
                ":Gender" : { S : md.Gender },
                ":Birthday" : { S : md.Birthday },
                ":HKID" : { S : UserImagePath },
                ":CurrentGrade" : { S : md.CurrentGrade },
                ":ModifiedDate" : { N : currentdate }
            },
            ReturnValues:"ALL_NEW"
        };

        dynamodb.updateItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','user_update',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','user_update',JSON.stringify(req.body));
    }
}
exports.delete_child = (req, res) => {
    try {
        TableName=process.env.USER_TABLE;
        var params = {
            Key: {
                'Id' : {S: req.body.Id},
            },
            TableName: process.env.PARTICIPANT
        };
        dynamodb.deleteItem(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','delete_child',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','delete_child',JSON.stringify(req.body));
    }
}
exports.get_child_by_userid = (req, res) => {
    try {
        md = req.params;
        var params = {
            TableName: process.env.PARTICIPANT,
            FilterExpression: "UserId = :UserId",
            ExpressionAttributeValues: {
                ":UserId": { S: md.userid}
            },
            ProjectionExpression: "Id,FirstName,LastName,Gender,Birthday,CurrentGrade,HKID",
        };
        dynamodb.scan(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','get_child_by_userid',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success',data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','get_child_by_userid',JSON.stringify(req.body));
    }
}   
exports.submited_contest = (req, res) => {
    try {
        TableName = process.env.CONTEST_TABLE;
        var params = {
        TableName: TableName,
        FilterExpression: "UserId = :UserId",
        //Limit: 11,
        ExpressionAttributeValues: {
            ":UserId": { S: req.params.id }
        },
        //ProjectionExpression: "Name",
        };
        dynamodb.scan(params, function (err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','submited_contest',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data.Items);
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','submited_contest',JSON.stringify(req.body));
    }
}
// exports.get_participate_contest = (req, res) => {
//     try {
//         TableName = process.env.Transactions_QA;
//         var params = {
//         TableName: TableName,
//         FilterExpression: "ParentId = :ParentId",
//         //Limit: 11,
//         ExpressionAttributeValues: {
//             ":ParentId": { S: req.params.id }
//         },
//         ProjectionExpression: "ContestId",
//         };
//         dynamodb.scan(params, function (err, data) {
//             if (err) {
//                 utility.errorResponse(res, 'error', err);
//                 utility.errorlog(err.stack,'user','submited_contest',JSON.stringify(req.body));
//             } else {
//                 utility.successResponse(res, 'Success', data.Items);
//             }
//         });
//     } catch (err) {
//         utility.errorlog(err.stack,'user','submited_contest',JSON.stringify(req.body));
//     }
// }
exports.create_table = (req, res) => {
    var TableData = [
        // {
        //     "TableName": "UserMaster_" + process.env.ENV,
        //     "HashKey": "Email",
        //     "SortKey": ""
        // },
        // {
        //     "TableName": "CountryMaster_" + process.env.ENV,
        //     "HashKey": "CountryCode",
        //     "SortKey": ""
        // },
        // {
        //     "TableName": "ContestMaster_" + process.env.ENV,
        //     "HashKey": "Id",
        //     "SortKey": ""
        // },
        // {
        //     "TableName": "ContestMasterTC_" + process.env.ENV,
        //     "HashKey": "Id",
        //     "SortKey": ""
        // },
        // {
        //     "TableName": "UserWishlist_" + process.env.ENV,
        //     "HashKey": "Id",
        //     "SortKey": ""
        // },
        // {
        //     "TableName": "Participant_" + process.env.ENV,
        //     "HashKey": "Id",
        //     "SortKey": ""
        // },
        // {
        //     "TableName": "CategoryMaster_" + process.env.ENV,
        //     "HashKey": "CategoryHashTag_TC",
        //     "SortKey": ""
        // },
        {
            "TableName": "Transactions_" + process.env.ENV,
            "HashKey": "Id",
            "SortKey": ""
        },
    ];
    TableData.forEach(function(createTable) {
        var params = {
            TableName : createTable["TableName"],
            KeySchema: [       
                { AttributeName: createTable["HashKey"], KeyType: "HASH"}
            ],
            AttributeDefinitions: [       
                { AttributeName: createTable["HashKey"], AttributeType: "S" }
            ],
            ProvisionedThroughput: {       
                ReadCapacityUnits: 1, 
                WriteCapacityUnits: 1
            }
          };
    
        dynamodb.createTable(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
            } else {
                res.send(JSON.stringify(data));
            }
        });
    });
}

exports.delete_table = (req, res) => {
    var params = {
        TableName: req.body.TableName
    };

    dynamodb.deleteTable(params, function(err, data) {
        if (err) {
            res.status(400).send("Unable to delete Error JSON:", JSON.stringify(err, null, 2));
        } else {
            res.send("Delete succeeded: "+JSON.stringify(data, null, 2))
        }
    });
}