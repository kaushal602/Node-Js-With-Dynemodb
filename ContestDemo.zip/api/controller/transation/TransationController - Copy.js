
var express = require('express');
var modelCategory = require('../../model/Category');
var utility = require('../../Utility/Utility');
var VerifyToken = require('../../auth/VerifyToken');
const uuid = require('uuid');
var bcrypt = require('bcryptjs');
require('dotenv').config();

var request = require('superagent');
/****************** Email Code*********** */
var nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');
var handlebars = require('handlebars');
var fs = require('fs');
var readHTMLFile = function(path, callback) {
    fs.readFile(path, {encoding: 'utf-8'}, function (err, html) {
        if (err) {
            throw err;
            callback(err);
        }
        else {
            callback(null, html);
        }
    });
};
smtpTransport = nodemailer.createTransport(smtpTransport({
    service: 'gmail',
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_USER_PASS
    }
}));
 /******************* Email code End****************/

var AWS = require("aws-sdk");
AWS.config.update({
  region: process.env.region,
  accessKeyId: process.env.aws_access_key_id,
  secretAccessKey: process.env.aws_secret_access_key,
  //endpoint: "http://192.168.1.14:8000/shell/"
});
var dynamodb = new AWS.DynamoDB();

exports.add_subscribe_user = (req, res) => {
    try {
        md = req.body;
        //console.log(md);
        
        var currentdate = new Date().getTime();  
        var grpdata12 = md.Groups;
        const CommomId = uuid.v1();
        //var ParticipentTable = process.env.ParticipentPaymentMaster_QA
        grpdata12.forEach(function(grpdata) {
            const id = uuid.v1();
            var params = {
                TableName: process.env.TRANSACTION,
                Item:{
                    Id : { S : id },
                    TransactionId :{ S : md.PaypalToken },
                    ContestId : { S : md.ContestId },
                    ContestName : { S : md.ContestName },
                    ContestType : { S : md.ContestType },
                    CommomId: { S : CommomId},
                    ParentId :{ S : md.ParentId },
                    ParentName :{ S : md.ParentName },
                    ParentEmail :{ S : md.ParentEmail },
                    ParentPhoneNumber :{ S : md.ParentPhoneNumber },
                    ChildId : { S : grpdata["ChildId"] },
                    ChildName : { S : grpdata["ChildName"] },
                    ChildBirthDay : { S : grpdata["ChildBirthDay"] },
                    ChildGender : { S : grpdata["ChildGender"] },
                    SubmissionType: { S : grpdata["SubmissionType"] },
                    TotalPayment : { S : md.TotalPayment },
                    IndividualPayment : { S : grpdata["IndividualPayment"] },
                    CreatedDate : { N : currentdate.toString() },
                }
            };

            dynamodb.putItem(params, function(err, data) {
                if (err) {
                    utility.errorResponse(res, 'error', err);
                    utility.errorlog(err.stack,'user','add_subscribe_user',JSON.stringify(req.body));
                } else {
                    // if(md.ContestType=='en'){
                    TableName = process.env.CONTEST_TABLE;
                    // } else {
                    //     TableName = process.env.CONTEST_TABLE_TC;
                    // }
                    //console.log(TableName);
                    
                    var params = {
                        TableName: TableName,
                            Key: {
                                'Id' : {S: md.ContestId},
                            },
                        };
                    dynamodb.getItem(params, function(err, data) {
                        if (err) {
                            utility.errorResponse(res, 'error', err);
                            utility.errorlog(err.stack,'contest','contest_getby_id',JSON.stringify(req.body));
                        } else {
                            //console.log(data.Item);
                            var arr = data.Item.Groups.L;
                            var group_data = [];
                            var gropdata12 = data.Item.Groups.L;
                            //console.log(gropdata12);
                            var i = 1;
                            gropdata12.forEach(function(gropdata) {
                                //console.log(gropdata);
                                //console.log(i);
                                i++;
                                //console.log(gropdata.M.SubmissionType.S);
                                //if(gropdata.M.TotalParticipant!=null){
                                    console.log(gropdata.M.SubmissionType.S);
                                    console.log(gropdata.M.TotalParticipant.S);
                                    //console.log(grpdata["SubmissionType"]);
                                    if(gropdata.M.SubmissionType.S==grpdata["SubmissionType"]){
                                        var total = parseInt(gropdata.M.TotalParticipant.S)+1;
                                    } else {
                                        var total = gropdata.M.TotalParticipant.S;
                                    }
                                // } else {
                                //     var total = '1';
                                // }
                                //console.log(total);
                                //console.log(gropdata.M.SubmissionType.S);
                                //console.log(grpdata["SubmissionType"]);
                                    //console.log('12');
                                var temp_data = {
                                    "M": {
                                        "SubmissionType": {
                                            "S": gropdata.M.SubmissionType.S
                                        },
                                        "NoOfParticipant": {
                                            "N": gropdata.M.NoOfParticipant.N
                                        },
                                        "Gender": {
                                            "S": gropdata.M.Gender.S
                                        },
                                        "GroupByAge": {
                                            "B": gropdata.M.GroupByAge.B
                                        },
                                        "GroupAge": {
                                            "S": gropdata.M.GroupAge.S
                                        },
                                        "Grade": {
                                            "S": gropdata.M.Grade.S
                                        },
                                        "Fees": {
                                            "S": gropdata.M.Fees.S
                                        },
                                        "TotalParticipant": {
                                            "S": total.toString()
                                        }
                                    }
                                }
                                group_data.push(temp_data);

                            }); 

                            var params = {
                                Key: {
                                    Id : { S:md.ContestId}
                                },
                                TableName: TableName,
                                UpdateExpression: "set Groups = :Groups",
                                ExpressionAttributeValues:{
                                    ":Groups": { L : group_data }
                                },
                                ReturnValues:"UPDATED_NEW"
                            };
                            dynamodb.updateItem(params, function(err, data) {
                                if (err) {
                                    utility.errorResponse(res, 'error', err);
                                    utility.errorlog(err.stack,'contest','contest_update',JSON.stringify(req.body));
                                } else {
                                    //utility.successResponse(res, 'Success', data);
                                }
                            });
                            
                            //utility.successResponse(res, 'Success', data);
                            //console.log(arr)
                        }
                    });
                    
                    //utility.successResponse(res, 'Success', data);
                    // if(md.TotalPayment!=''){
                    //     const PaymentId = uuid.v1();
                    //     //utility.successResponse(res, 'Success', data);
                    //     var params = {
                    //         TableName: process.env.PARTICIPANT_PAYMENT,
                    //         Item:{
                    //             Id : { S : PaymentId },
                    //             ParticipentID : { S : id },
                    //             PaypalToken :{ S : md.PaypalToken },
                    //             TotalPayment : { S : md.TotalPayment },
                    //             IndividualPayment : { S : grpdata["IndividualPayment"] },
                    //             CreatedDate : { N : currentdate },
                    //         }
                    //     };
                    //     dynamodb.putItem(params, function(err, data) {
                    //         if (err) {
                    //             utility.errorResponse(res, 'error2', err);
                    //             utility.errorlog(err.stack,'user','add_user_payment',JSON.stringify(req.body));
                    //         } else {
                    //             utility.successResponse(res, 'Success', data);
                    //         }
                    //     });
                    // } else {
                    //     utility.successResponse(res, 'Success', data);
                    // }
                }
            });
        });
        utility.successResponse(res, 'Success', 'data');
    } catch (err) {
        utility.errorlog(err.stack,'contest','add_subscribe_user',JSON.stringify(req.body));
    }
}
exports.get_subscribe_user = (req, res) => {
    try {
        md = req.body;
        var filterExpression =  ""; 
        var expressionAttributeValues = {};
        var contentIdName = ":ContestId";
        filterExpression = 'ContestId ='+ contentIdName;
        expressionAttributeValues[contentIdName] ={ S: md.ContestId};
        var params = {
            TableName: process.env.TRANSACTION,
            ExpressionAttributeValues:expressionAttributeValues, // {":Category": { S: Category}},
            FilterExpression: filterExpression,
        };
        dynamodb.scan(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','get_subscribe_user',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success1', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','get_subscribe_user',JSON.stringify(req.body));
    }
}
exports.get_participant_by_type = (req, res) => {
    try {
        md = req.body;
        var filterExpression =  ""; 
        var expressionAttributeValues = {};
        var contentIdName = ":ContestId";
        filterExpression = 'ContestId ='+ contentIdName;
        expressionAttributeValues[contentIdName] ={ S: md.ContestId};

        var contentIdName = ":SubmissionType";
        var SubmissionType = '';
        SubmissionType = 'SubmissionType='+ contentIdName;
        expressionAttributeValues[contentIdName] ={ S: md.SubmissionType};

        if(filterExpression!=''){
            filterExpression=filterExpression+' AND '+SubmissionType;
        }else {
            filterExpression=filterExpression+SubmissionType;
        }
        //console.log(filterExpression);
        var params = {
            TableName: process.env.TRANSACTION,
            ExpressionAttributeValues:expressionAttributeValues, // {":Category": { S: Category}},
            FilterExpression: filterExpression,
        };
        dynamodb.scan(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','get_participant_by_type',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success1', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','get_participant_by_type',JSON.stringify(req.body));
    }
}

exports.get_transation_details = (req, res) => {
    try {
        var params = {
            TableName: process.env.TRANSACTION,
        };
        dynamodb.scan(params, function(err, data) {
            if (err) {
                utility.errorResponse(res, 'error', err);
                utility.errorlog(err.stack,'user','get_transation_details',JSON.stringify(req.body));
            } else {
                utility.successResponse(res, 'Success', data)
            }
        });
    } catch (err) {
        utility.errorlog(err.stack,'user','get_transation_details',JSON.stringify(req.body));
    }
}

exports.payment_email = (req, res) => {
    md = req.body;
    
    readHTMLFile(__dirname + '/paymentemail.html', function(err, html) {
        var template = handlebars.compile(html);
        var replacements = {
            name: md.Name,
            Amount: md.Amount,
            Date: md.Date,
            ContestTitle: md.ContestTitle,
            StartDate: md.StartDate,
            EndDate: md.EndDate,
            Address: md.Address,
            Description: md.Description,
            TodayDate: md.TodayDate,
            Baseurl: md.Baseurl,
            ContestId: md.ContestId,
        };
        var htmlToSend = template(replacements);
        var mailOptions = {
            from: process.env.SMTP_USER,
            to : md.Email,
            subject : 'Payment successfully',
            html : htmlToSend
            };
        smtpTransport.sendMail(mailOptions, function (error, response) {
            if (error) {
                //console.log(error);
                //callback(error);
            }
            if(response){
                //console.log(response);
            }
        });
    });
}