const express = require("express");
const router = express.Router();
var VerifyToken = require('../auth/VerifyToken');

const SubCategoryController = require('../controller/master/SubCategoryController');

router.get("/", SubCategoryController.subcategory_get_all);
router.get("/:id", SubCategoryController.subcategory_get_by_id);
//router.get("/detail/:id", SubCategoryController.subcategory_get_detail);
router.get("/:categoryhashtag?/:language", SubCategoryController.subcategory_get_by_category);
router.post("/", VerifyToken, SubCategoryController.subcategory_insert);
router.put("/", VerifyToken, SubCategoryController.subcategory_update);
router.post("/statuschange/", SubCategoryController.subcategory_statuschange);
router.delete("/:id", VerifyToken, SubCategoryController.subcategory_delete);

module.exports = router;