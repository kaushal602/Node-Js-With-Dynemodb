const express = require("express");
const router = express.Router();

var VerifyToken = require('../auth/VerifyToken');

const CotestController = require('../controller/contest/ContestController');

router.post("/", VerifyToken, CotestController.contest_create);
router.get("/:prefLang?", CotestController.contest_get_all);

router.get("/home/contestlist", CotestController.home_contest_list);
router.get("/clients/:prefLang", CotestController.contest_get_all_client);
//router.get("/:country?/:category?/:contest?", CotestController.search_contest);
//router.post("/search-result", CotestController.search_contest);
router.get("/detail/:id?/:prefLang?", CotestController.contest_getby_id);
router.get("/edit/detail/:id?/:prefLang?", VerifyToken, CotestController.contest_edit_getby_id);
router.put("/", VerifyToken, CotestController.contest_update);
router.put("/changestatus/", VerifyToken, CotestController.contest_changestatus);
// router.post("/addcontestparticipant", VerifyToken, CotestController.add_subscribe_user);
// router.post("/getcontestparticipant", CotestController.get_subscribe_user);
// router.post("/getparticipantbytype", CotestController.get_participant_by_type);
// router.post("/paymentsuccessemail", VerifyToken, CotestController.payment_email);
//router.post("/gettransactionsdetails", CotestController.get_transation_details);
router.post("/getcontestaddress", CotestController.get_contest_address);
router.delete("/:id", VerifyToken, CotestController.contest_delete);
//router.put("/updateimgpath/", CotestController.contest_update_image);



module.exports = router;