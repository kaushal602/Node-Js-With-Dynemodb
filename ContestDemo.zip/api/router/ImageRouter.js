const express = require("express");
const router = express.Router();

const ImageController = require('../controller/uploadimage/ImageController');
//const ImageController = require('../controller/uploadimage/ImageCon1');
var _ = require('lodash');
var AWS = require("aws-sdk");
AWS.config.update({
    region: process.env.region,
    accessKeyId: process.env.aws_access_key_id,
    secretAccessKey: process.env.aws_secret_access_key
});

module.exports = router;