// const requestCategory = {
//     id: String,
// };

const requestCategory = {
    CategoryHashTag : String,
    CategoryName : String,
  //  CategoryImage : String,
}

// module.exports = requestCategory;

// schemas = {
//     requestCategory: {
//         CategoryHashTag: String,
//         CategoryName : String,
//         CategoryImage : String,
//     }
// }

module.exports = requestCategory;