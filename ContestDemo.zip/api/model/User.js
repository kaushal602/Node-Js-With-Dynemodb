const userData = {
    FirstName : String,
    LastName : String,
}

module.exports = userData;